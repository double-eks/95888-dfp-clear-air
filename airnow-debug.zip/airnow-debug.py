import logging
import re
from datetime import datetime, timedelta
from urllib.request import urlopen

# import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from bs4 import BeautifulSoup, Tag

from airnow import AqiLegend
from console import Console

url = 'https://www.airnow.gov/?city=Pittsburgh&state=PA&country=USA'
path = 'AirNow.gov.html'
html = urlopen(url)
urlBs = BeautifulSoup(html.read(), "lxml")
urlWeather = urlBs.find('div', attrs={'class': 'weather-value'})
print(urlWeather)

print('-' * 10)

with open(path) as copy:
    savedHtml = copy.read()
localBs = BeautifulSoup(savedHtml, "html.parser")
localWeather = localBs.find('div', attrs={'class': 'weather-value'})
print(localWeather)
